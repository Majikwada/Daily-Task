import { useState } from 'react';
import { Sparkles, Gift } from 'lucide-react';
import BottomTabBar from '@/components/navigation/BottomTabBar';
import UnityAdBanner, { showInterstitialAd, showRewardedAd } from '@/components/ads/UnityAdBanner';

// Widgets
import DateTimeWidget from '@/components/widgets/DateTimeWidget';
import TodoWidget from '@/components/widgets/TodoWidget';
import NotesWidget from '@/components/widgets/NotesWidget';
import PomodoroWidget from '@/components/widgets/PomodoroWidget';
import CalculatorWidget from '@/components/widgets/CalculatorWidget';
import WeatherWidget from '@/components/widgets/WeatherWidget';
import HabitWidget from '@/components/widgets/HabitWidget';
import UnitConverterWidget from '@/components/widgets/UnitConverterWidget';
import CurrencyConverterWidget from '@/components/widgets/CurrencyConverterWidget';
import ExpenseTrackerWidget from '@/components/widgets/ExpenseTrackerWidget';
import StopwatchWidget from '@/components/widgets/StopwatchWidget';

// Unity Ads Configuration
const UNITY_ADS = {
  gameId: '6032198',
  banner: 'Banner_Android',
  interstitial: 'Interstitial_Android',
  rewarded: 'Rewarded_Android',
};

const Index = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [rewardPoints, setRewardPoints] = useState(0);

  const handleTabChange = (tab: string) => {
    // Show interstitial ad occasionally when switching tabs
    if (Math.random() > 0.7) {
      showInterstitialAd(UNITY_ADS.gameId, UNITY_ADS.interstitial);
    }
    setActiveTab(tab);
  };

  const handleWatchRewardedAd = () => {
    showRewardedAd(UNITY_ADS.gameId, UNITY_ADS.rewarded, (success) => {
      if (success) {
        setRewardPoints(prev => prev + 10);
      }
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <DateTimeWidget />
              <WeatherWidget />
            </div>
            
            {/* Banner Ad */}
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-home-1" 
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <HabitWidget />
              <NotesWidget />
            </div>

            {/* Rewarded Ad Button */}
            <div className="widget-card flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Gift className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Earn Rewards</p>
                  <p className="text-xs text-muted-foreground">Watch an ad to earn points</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold text-primary">{rewardPoints} pts</span>
                <button 
                  onClick={handleWatchRewardedAd}
                  className="btn-primary text-sm"
                >
                  Watch Ad
                </button>
              </div>
            </div>

            {/* Another Banner Ad */}
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-home-2" 
            />
          </div>
        );

      case 'tasks':
        return (
          <div className="space-y-4">
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-tasks-top" 
            />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <TodoWidget />
              <NotesWidget />
            </div>
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-tasks-bottom" 
            />
          </div>
        );

      case 'tools':
        return (
          <div className="space-y-4">
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-tools-top" 
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <CalculatorWidget />
              <UnitConverterWidget />
            </div>
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-tools-bottom" 
            />
          </div>
        );

      case 'timer':
        return (
          <div className="space-y-4">
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-timer-top" 
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <PomodoroWidget />
              <StopwatchWidget />
            </div>
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-timer-bottom" 
            />
          </div>
        );

      case 'money':
        return (
          <div className="space-y-4">
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-money-top" 
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <CurrencyConverterWidget />
              <ExpenseTrackerWidget />
            </div>
            <UnityAdBanner 
              gameId={UNITY_ADS.gameId} 
              placementId={UNITY_ADS.banner} 
              containerId="ad-money-bottom" 
            />
          </div>
        );

      default:
        return null;
    }
  };

  const getPageTitle = () => {
    switch (activeTab) {
      case 'home': return 'Dashboard';
      case 'tasks': return 'Tasks & Notes';
      case 'tools': return 'Tools';
      case 'timer': return 'Timers';
      case 'money': return 'Money';
      default: return 'Daily Companion';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        {/* Header */}
        <header className="mb-4 animate-fade-in">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-display font-semibold text-foreground">
                {getPageTitle()}
              </h1>
              <p className="text-muted-foreground text-xs md:text-sm">
                Your personal productivity hub
              </p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="animate-fade-in">
          {renderContent()}
        </main>
      </div>

      {/* Bottom Navigation */}
      <BottomTabBar activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

export default Index;
