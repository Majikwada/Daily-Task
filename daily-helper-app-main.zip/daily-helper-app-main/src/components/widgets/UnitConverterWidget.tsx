import { useState } from 'react';
import { ArrowRightLeft, Scale, Thermometer, Ruler } from 'lucide-react';

type ConversionType = 'length' | 'weight' | 'temperature';

const conversions = {
  length: {
    units: ['meters', 'feet', 'inches', 'centimeters', 'kilometers', 'miles'],
    convert: (value: number, from: string, to: string): number => {
      const toMeters: Record<string, number> = {
        meters: 1, feet: 0.3048, inches: 0.0254, centimeters: 0.01, kilometers: 1000, miles: 1609.34
      };
      const meters = value * toMeters[from];
      return meters / toMeters[to];
    }
  },
  weight: {
    units: ['kilograms', 'pounds', 'ounces', 'grams', 'tons'],
    convert: (value: number, from: string, to: string): number => {
      const toKg: Record<string, number> = {
        kilograms: 1, pounds: 0.453592, ounces: 0.0283495, grams: 0.001, tons: 1000
      };
      const kg = value * toKg[from];
      return kg / toKg[to];
    }
  },
  temperature: {
    units: ['celsius', 'fahrenheit', 'kelvin'],
    convert: (value: number, from: string, to: string): number => {
      let celsius = value;
      if (from === 'fahrenheit') celsius = (value - 32) * 5/9;
      if (from === 'kelvin') celsius = value - 273.15;
      
      if (to === 'celsius') return celsius;
      if (to === 'fahrenheit') return celsius * 9/5 + 32;
      return celsius + 273.15;
    }
  }
};

const UnitConverterWidget = () => {
  const [type, setType] = useState<ConversionType>('length');
  const [fromValue, setFromValue] = useState('1');
  const [fromUnit, setFromUnit] = useState(conversions.length.units[0]);
  const [toUnit, setToUnit] = useState(conversions.length.units[1]);

  const handleTypeChange = (newType: ConversionType) => {
    setType(newType);
    setFromUnit(conversions[newType].units[0]);
    setToUnit(conversions[newType].units[1]);
    setFromValue('1');
  };

  const result = conversions[type].convert(
    parseFloat(fromValue) || 0,
    fromUnit,
    toUnit
  );

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  return (
    <div className="widget-card h-full">
      <div className="flex items-center gap-2 mb-4">
        <Ruler className="w-4 h-4 text-primary" />
        <span className="widget-title mb-0">Unit Converter</span>
      </div>

      <div className="flex gap-2 mb-4">
        {[
          { type: 'length' as ConversionType, icon: Ruler, label: 'Length' },
          { type: 'weight' as ConversionType, icon: Scale, label: 'Weight' },
          { type: 'temperature' as ConversionType, icon: Thermometer, label: 'Temp' },
        ].map(({ type: t, icon: Icon, label }) => (
          <button
            key={t}
            onClick={() => handleTypeChange(t)}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-medium transition-all duration-200 flex items-center justify-center gap-1 ${
              type === t
                ? 'bg-primary text-primary-foreground'
                : 'bg-secondary text-secondary-foreground hover:bg-muted'
            }`}
          >
            <Icon className="w-3 h-3" />
            {label}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        <div>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="input-field w-full text-lg mb-2"
            placeholder="Enter value"
          />
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value)}
            className="input-field w-full text-sm capitalize"
          >
            {conversions[type].units.map(unit => (
              <option key={unit} value={unit}>{unit}</option>
            ))}
          </select>
        </div>

        <button
          onClick={swapUnits}
          className="mx-auto flex items-center justify-center w-10 h-10 rounded-full bg-secondary hover:bg-muted transition-all"
        >
          <ArrowRightLeft className="w-4 h-4 text-muted-foreground" />
        </button>

        <div>
          <div className="input-field w-full text-lg mb-2 text-primary font-medium">
            {result.toFixed(4)}
          </div>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value)}
            className="input-field w-full text-sm capitalize"
          >
            {conversions[type].units.map(unit => (
              <option key={unit} value={unit}>{unit}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default UnitConverterWidget;
