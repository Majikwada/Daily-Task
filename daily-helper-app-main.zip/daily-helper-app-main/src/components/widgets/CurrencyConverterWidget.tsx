import { useState } from 'react';
import { DollarSign, ArrowRightLeft, RefreshCw } from 'lucide-react';

const currencies = [
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1 },
  { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.92 },
  { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.79 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rate: 149.50 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', rate: 83.12 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', rate: 1.53 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', rate: 1.36 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rate: 7.24 },
];

const CurrencyConverterWidget = () => {
  const [amount, setAmount] = useState('100');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');

  const fromRate = currencies.find(c => c.code === fromCurrency)?.rate || 1;
  const toRate = currencies.find(c => c.code === toCurrency)?.rate || 1;
  const result = (parseFloat(amount) || 0) / fromRate * toRate;
  const toSymbol = currencies.find(c => c.code === toCurrency)?.symbol || '';

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  return (
    <div className="widget-card h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-accent" />
          <span className="widget-title mb-0">Currency</span>
        </div>
        <button className="p-1.5 rounded-lg bg-secondary hover:bg-muted transition-all">
          <RefreshCw className="w-3 h-3 text-muted-foreground" />
        </button>
      </div>

      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Amount</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="input-field w-full text-lg"
            placeholder="Enter amount"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={fromCurrency}
            onChange={(e) => setFromCurrency(e.target.value)}
            className="input-field flex-1 text-sm"
          >
            {currencies.map(c => (
              <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
            ))}
          </select>

          <button
            onClick={swapCurrencies}
            className="p-2 rounded-xl bg-secondary hover:bg-muted transition-all"
          >
            <ArrowRightLeft className="w-4 h-4 text-muted-foreground" />
          </button>

          <select
            value={toCurrency}
            onChange={(e) => setToCurrency(e.target.value)}
            className="input-field flex-1 text-sm"
          >
            {currencies.map(c => (
              <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
            ))}
          </select>
        </div>

        <div className="bg-primary/10 rounded-xl p-4 text-center">
          <p className="text-2xl font-semibold text-primary">
            {toSymbol}{result.toFixed(2)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            1 {fromCurrency} = {(toRate / fromRate).toFixed(4)} {toCurrency}
          </p>
        </div>
      </div>
    </div>
  );
};

export default CurrencyConverterWidget;
