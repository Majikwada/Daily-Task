import { useState } from 'react';
import { Receipt, Plus, Trash2, TrendingUp, TrendingDown } from 'lucide-react';

interface Expense {
  id: number;
  description: string;
  amount: number;
  category: string;
  type: 'expense' | 'income';
  date: Date;
}

const categories = ['🍔 Food', '🚗 Transport', '🛒 Shopping', '💡 Bills', '🎮 Entertainment', '💰 Income'];

const ExpenseTrackerWidget = () => {
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: 1, description: 'Groceries', amount: 45.50, category: '🍔 Food', type: 'expense', date: new Date() },
    { id: 2, description: 'Salary', amount: 3000, category: '💰 Income', type: 'income', date: new Date() },
    { id: 3, description: 'Bus ticket', amount: 2.50, category: '🚗 Transport', type: 'expense', date: new Date() },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(categories[0]);
  const [type, setType] = useState<'expense' | 'income'>('expense');

  const addExpense = () => {
    if (description && amount) {
      setExpenses([
        ...expenses,
        {
          id: Date.now(),
          description,
          amount: parseFloat(amount),
          category,
          type,
          date: new Date(),
        },
      ]);
      setDescription('');
      setAmount('');
      setShowForm(false);
    }
  };

  const deleteExpense = (id: number) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  const totalIncome = expenses.filter(e => e.type === 'income').reduce((sum, e) => sum + e.amount, 0);
  const totalExpenses = expenses.filter(e => e.type === 'expense').reduce((sum, e) => sum + e.amount, 0);
  const balance = totalIncome - totalExpenses;

  return (
    <div className="widget-card h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Receipt className="w-4 h-4 text-primary" />
          <span className="widget-title mb-0">Expenses</span>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="p-1.5 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-xl p-2 text-center">
          <TrendingUp className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
          <p className="text-xs text-emerald-600 font-medium">${totalIncome.toFixed(0)}</p>
        </div>
        <div className="bg-rose-100 dark:bg-rose-900/30 rounded-xl p-2 text-center">
          <TrendingDown className="w-4 h-4 text-rose-600 mx-auto mb-1" />
          <p className="text-xs text-rose-600 font-medium">${totalExpenses.toFixed(0)}</p>
        </div>
        <div className="bg-secondary rounded-xl p-2 text-center">
          <p className="text-xs text-muted-foreground">Balance</p>
          <p className={`text-xs font-medium ${balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            ${balance.toFixed(0)}
          </p>
        </div>
      </div>

      {/* Add Form */}
      {showForm && (
        <div className="bg-secondary rounded-xl p-3 mb-3 space-y-2">
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Description"
            className="input-field w-full text-sm"
          />
          <div className="flex gap-2">
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount"
              className="input-field flex-1 text-sm"
            />
            <select
              value={type}
              onChange={(e) => setType(e.target.value as 'expense' | 'income')}
              className="input-field text-sm"
            >
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="input-field w-full text-sm"
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <button onClick={addExpense} className="btn-primary w-full text-sm">
            Add
          </button>
        </div>
      )}

      {/* Expense List */}
      <div className="space-y-2 max-h-[200px] overflow-y-auto">
        {expenses.slice(-5).reverse().map((expense) => (
          <div
            key={expense.id}
            className="flex items-center justify-between bg-secondary rounded-xl p-2 group"
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">{expense.category.split(' ')[0]}</span>
              <div>
                <p className="text-sm font-medium text-foreground">{expense.description}</p>
                <p className="text-xs text-muted-foreground">{expense.category}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-medium ${expense.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                {expense.type === 'income' ? '+' : '-'}${expense.amount.toFixed(2)}
              </span>
              <button
                onClick={() => deleteExpense(expense.id)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/10 rounded transition-all"
              >
                <Trash2 className="w-3 h-3 text-destructive" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpenseTrackerWidget;
