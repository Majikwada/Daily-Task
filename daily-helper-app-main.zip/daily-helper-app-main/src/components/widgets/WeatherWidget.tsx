import { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Droplets, Wind } from 'lucide-react';

const WeatherWidget = () => {
  const [weather, setWeather] = useState({
    temp: 24,
    condition: 'sunny',
    humidity: 45,
    wind: 12,
    location: 'Your City',
  });

  const getWeatherIcon = () => {
    switch (weather.condition) {
      case 'sunny':
        return <Sun className="w-12 h-12 text-amber-400" />;
      case 'cloudy':
        return <Cloud className="w-12 h-12 text-slate-400" />;
      case 'rainy':
        return <CloudRain className="w-12 h-12 text-sky-400" />;
      default:
        return <Sun className="w-12 h-12 text-amber-400" />;
    }
  };

  const conditions = ['sunny', 'cloudy', 'rainy'];
  
  useEffect(() => {
    // Simulate weather changes
    const interval = setInterval(() => {
      setWeather(prev => ({
        ...prev,
        temp: Math.floor(Math.random() * 15) + 18,
        condition: conditions[Math.floor(Math.random() * conditions.length)],
        humidity: Math.floor(Math.random() * 40) + 30,
        wind: Math.floor(Math.random() * 20) + 5,
      }));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="widget-card">
      <div className="flex items-center gap-2 mb-4">
        <Cloud className="w-4 h-4 text-primary" />
        <span className="widget-title mb-0">Weather</span>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-4xl font-light text-foreground">{weather.temp}°</p>
          <p className="text-sm text-muted-foreground capitalize">{weather.condition}</p>
          <p className="text-xs text-muted-foreground">{weather.location}</p>
        </div>
        <div className="animate-pulse-soft">
          {getWeatherIcon()}
        </div>
      </div>

      <div className="flex gap-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Droplets className="w-4 h-4 text-sky-400" />
          <span>{weather.humidity}%</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Wind className="w-4 h-4 text-slate-400" />
          <span>{weather.wind} km/h</span>
        </div>
      </div>
    </div>
  );
};

export default WeatherWidget;
