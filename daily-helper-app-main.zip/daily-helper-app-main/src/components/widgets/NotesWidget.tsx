import { useState } from 'react';
import { StickyNote, Plus, X } from 'lucide-react';

interface Note {
  id: number;
  content: string;
  color: string;
}

const colors = [
  'bg-amber-100',
  'bg-rose-100',
  'bg-sky-100',
  'bg-emerald-100',
  'bg-violet-100',
];

const NotesWidget = () => {
  const [notes, setNotes] = useState<Note[]>([
    { id: 1, content: 'Remember to drink water 💧', color: 'bg-sky-100' },
    { id: 2, content: 'Ideas for weekend project', color: 'bg-amber-100' },
  ]);
  const [newNote, setNewNote] = useState('');

  const addNote = () => {
    if (newNote.trim()) {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      setNotes([...notes, { id: Date.now(), content: newNote.trim(), color: randomColor }]);
      setNewNote('');
    }
  };

  const deleteNote = (id: number) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  return (
    <div className="widget-card">
      <div className="flex items-center gap-2 mb-4">
        <StickyNote className="w-4 h-4 text-accent" />
        <span className="widget-title mb-0">Quick Notes</span>
      </div>

      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addNote()}
          placeholder="Jot something down..."
          className="input-field flex-1 text-sm"
        />
        <button
          onClick={addNote}
          className="bg-accent text-accent-foreground hover:opacity-90 transition-all duration-200 rounded-xl p-3"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 max-h-[200px] overflow-y-auto">
        {notes.map((note) => (
          <div
            key={note.id}
            className={`${note.color} p-3 rounded-xl relative group`}
          >
            <button
              onClick={() => deleteNote(note.id)}
              className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 p-1 hover:bg-black/10 rounded-lg transition-all duration-200"
            >
              <X className="w-3 h-3 text-foreground/70" />
            </button>
            <p className="text-xs text-foreground/80 pr-4">{note.content}</p>
          </div>
        ))}
      </div>

      {notes.length === 0 && (
        <p className="text-center text-muted-foreground text-sm py-4">
          No notes yet
        </p>
      )}
    </div>
  );
};

export default NotesWidget;
