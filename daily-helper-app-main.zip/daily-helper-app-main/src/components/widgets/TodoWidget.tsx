import { useState } from 'react';
import { Plus, Check, Trash2, ListTodo } from 'lucide-react';

interface Todo {
  id: number;
  text: string;
  completed: boolean;
}

const TodoWidget = () => {
  const [todos, setTodos] = useState<Todo[]>([
    { id: 1, text: 'Morning meditation', completed: true },
    { id: 2, text: 'Review project goals', completed: false },
    { id: 3, text: 'Call mom', completed: false },
  ]);
  const [newTodo, setNewTodo] = useState('');

  const addTodo = () => {
    if (newTodo.trim()) {
      setTodos([...todos, { id: Date.now(), text: newTodo.trim(), completed: false }]);
      setNewTodo('');
    }
  };

  const toggleTodo = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const completedCount = todos.filter(t => t.completed).length;

  return (
    <div className="widget-card row-span-2">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <ListTodo className="w-4 h-4 text-primary" />
          <span className="widget-title mb-0">Tasks</span>
        </div>
        <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-full">
          {completedCount}/{todos.length}
        </span>
      </div>

      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
          placeholder="Add a task..."
          className="input-field flex-1 text-sm"
        />
        <button
          onClick={addTodo}
          className="btn-primary p-3 flex items-center justify-center"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-2 max-h-[300px] overflow-y-auto">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-200 group ${
              todo.completed ? 'bg-muted/50' : 'bg-secondary hover:bg-muted'
            }`}
          >
            <button
              onClick={() => toggleTodo(todo.id)}
              className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                todo.completed
                  ? 'bg-primary border-primary'
                  : 'border-muted-foreground/30 hover:border-primary'
              }`}
            >
              {todo.completed && <Check className="w-3 h-3 text-primary-foreground" />}
            </button>
            <span
              className={`flex-1 text-sm transition-all duration-200 ${
                todo.completed ? 'line-through text-muted-foreground' : 'text-foreground'
              }`}
            >
              {todo.text}
            </span>
            <button
              onClick={() => deleteTodo(todo.id)}
              className="opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/10 rounded-lg transition-all duration-200"
            >
              <Trash2 className="w-4 h-4 text-destructive" />
            </button>
          </div>
        ))}
        
        {todos.length === 0 && (
          <p className="text-center text-muted-foreground text-sm py-8">
            No tasks yet. Add one above!
          </p>
        )}
      </div>
    </div>
  );
};

export default TodoWidget;
