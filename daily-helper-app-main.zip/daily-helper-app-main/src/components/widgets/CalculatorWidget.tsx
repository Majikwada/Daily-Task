import { useState } from 'react';
import { Calculator, Delete } from 'lucide-react';

const CalculatorWidget = () => {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      let result = 0;

      switch (operation) {
        case '+': result = currentValue + inputValue; break;
        case '-': result = currentValue - inputValue; break;
        case '×': result = currentValue * inputValue; break;
        case '÷': result = inputValue !== 0 ? currentValue / inputValue : 0; break;
      }

      setDisplay(String(result));
      setPreviousValue(result);
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  };

  const calculate = () => {
    if (!operation || previousValue === null) return;

    const inputValue = parseFloat(display);
    let result = 0;

    switch (operation) {
      case '+': result = previousValue + inputValue; break;
      case '-': result = previousValue - inputValue; break;
      case '×': result = previousValue * inputValue; break;
      case '÷': result = inputValue !== 0 ? previousValue / inputValue : 0; break;
    }

    setDisplay(String(result));
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(true);
  };

  const Button = ({ 
    children, 
    onClick, 
    className = '' 
  }: { 
    children: React.ReactNode; 
    onClick: () => void; 
    className?: string;
  }) => (
    <button
      onClick={onClick}
      className={`p-3 rounded-xl font-medium transition-all duration-200 active:scale-95 ${className}`}
    >
      {children}
    </button>
  );

  return (
    <div className="widget-card">
      <div className="flex items-center gap-2 mb-4">
        <Calculator className="w-4 h-4 text-primary" />
        <span className="widget-title mb-0">Calculator</span>
      </div>

      <div className="bg-secondary rounded-xl p-4 mb-3">
        <div className="text-right text-2xl font-light tabular-nums text-foreground truncate">
          {display}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        <Button onClick={clear} className="bg-destructive/10 text-destructive hover:bg-destructive/20">C</Button>
        <Button onClick={() => setDisplay(display.slice(0, -1) || '0')} className="bg-secondary hover:bg-muted">
          <Delete className="w-4 h-4 mx-auto" />
        </Button>
        <Button onClick={() => setDisplay(String(parseFloat(display) / 100))} className="bg-secondary hover:bg-muted">%</Button>
        <Button onClick={() => performOperation('÷')} className="bg-primary text-primary-foreground hover:opacity-90">÷</Button>

        <Button onClick={() => inputDigit('7')} className="bg-secondary hover:bg-muted">7</Button>
        <Button onClick={() => inputDigit('8')} className="bg-secondary hover:bg-muted">8</Button>
        <Button onClick={() => inputDigit('9')} className="bg-secondary hover:bg-muted">9</Button>
        <Button onClick={() => performOperation('×')} className="bg-primary text-primary-foreground hover:opacity-90">×</Button>

        <Button onClick={() => inputDigit('4')} className="bg-secondary hover:bg-muted">4</Button>
        <Button onClick={() => inputDigit('5')} className="bg-secondary hover:bg-muted">5</Button>
        <Button onClick={() => inputDigit('6')} className="bg-secondary hover:bg-muted">6</Button>
        <Button onClick={() => performOperation('-')} className="bg-primary text-primary-foreground hover:opacity-90">−</Button>

        <Button onClick={() => inputDigit('1')} className="bg-secondary hover:bg-muted">1</Button>
        <Button onClick={() => inputDigit('2')} className="bg-secondary hover:bg-muted">2</Button>
        <Button onClick={() => inputDigit('3')} className="bg-secondary hover:bg-muted">3</Button>
        <Button onClick={() => performOperation('+')} className="bg-primary text-primary-foreground hover:opacity-90">+</Button>

        <Button onClick={() => inputDigit('0')} className="col-span-2 bg-secondary hover:bg-muted">0</Button>
        <Button onClick={inputDecimal} className="bg-secondary hover:bg-muted">.</Button>
        <Button onClick={calculate} className="bg-accent text-accent-foreground hover:opacity-90">=</Button>
      </div>
    </div>
  );
};

export default CalculatorWidget;
