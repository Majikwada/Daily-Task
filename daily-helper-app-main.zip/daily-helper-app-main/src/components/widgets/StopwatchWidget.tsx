import { useState, useEffect, useRef } from 'react';
import { Clock, Play, Pause, RotateCcw, Flag, Bell, X } from 'lucide-react';

const StopwatchWidget = () => {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const [mode, setMode] = useState<'stopwatch' | 'alarm'>('stopwatch');
  const [alarmTime, setAlarmTime] = useState('');
  const [alarmSet, setAlarmSet] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTime(prev => prev + 10);
      }, 10);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning]);

  // Check alarm
  useEffect(() => {
    if (alarmSet && alarmTime) {
      const checkAlarm = setInterval(() => {
        const now = new Date();
        const [hours, minutes] = alarmTime.split(':').map(Number);
        if (now.getHours() === hours && now.getMinutes() === minutes) {
          alert('⏰ Alarm!');
          setAlarmSet(false);
        }
      }, 1000);
      return () => clearInterval(checkAlarm);
    }
  }, [alarmSet, alarmTime]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const centiseconds = Math.floor((ms % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centiseconds.toString().padStart(2, '0')}`;
  };

  const toggleTimer = () => setIsRunning(!isRunning);
  const reset = () => {
    setIsRunning(false);
    setTime(0);
    setLaps([]);
  };
  const addLap = () => setLaps([...laps, time]);

  return (
    <div className="widget-card h-full">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-4 h-4 text-accent" />
        <span className="widget-title mb-0">Timer</span>
      </div>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setMode('stopwatch')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium transition-all ${
            mode === 'stopwatch' ? 'bg-accent text-accent-foreground' : 'bg-secondary hover:bg-muted'
          }`}
        >
          Stopwatch
        </button>
        <button
          onClick={() => setMode('alarm')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium transition-all ${
            mode === 'alarm' ? 'bg-accent text-accent-foreground' : 'bg-secondary hover:bg-muted'
          }`}
        >
          Alarm
        </button>
      </div>

      {mode === 'stopwatch' ? (
        <>
          <div className="text-center mb-4">
            <p className="text-4xl font-light tabular-nums text-foreground">
              {formatTime(time)}
            </p>
          </div>

          <div className="flex gap-2 justify-center mb-4">
            <button
              onClick={toggleTimer}
              className={`p-3 rounded-xl transition-all ${
                isRunning ? 'bg-muted' : 'bg-accent text-accent-foreground'
              }`}
            >
              {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </button>
            <button
              onClick={addLap}
              disabled={!isRunning}
              className="p-3 rounded-xl bg-secondary hover:bg-muted transition-all disabled:opacity-50"
            >
              <Flag className="w-5 h-5" />
            </button>
            <button onClick={reset} className="p-3 rounded-xl bg-secondary hover:bg-muted transition-all">
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {laps.length > 0 && (
            <div className="max-h-[100px] overflow-y-auto space-y-1">
              {laps.map((lap, i) => (
                <div key={i} className="flex justify-between text-sm bg-secondary rounded-lg px-3 py-1.5">
                  <span className="text-muted-foreground">Lap {i + 1}</span>
                  <span className="tabular-nums">{formatTime(lap)}</span>
                </div>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <input
              type="time"
              value={alarmTime}
              onChange={(e) => setAlarmTime(e.target.value)}
              className="input-field flex-1 text-lg text-center"
            />
          </div>
          
          {alarmSet ? (
            <div className="bg-accent/10 rounded-xl p-4 text-center">
              <Bell className="w-8 h-8 text-accent mx-auto mb-2 animate-pulse" />
              <p className="text-sm font-medium text-foreground">Alarm set for {alarmTime}</p>
              <button
                onClick={() => setAlarmSet(false)}
                className="mt-2 text-xs text-destructive hover:underline flex items-center gap-1 mx-auto"
              >
                <X className="w-3 h-3" /> Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => alarmTime && setAlarmSet(true)}
              disabled={!alarmTime}
              className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Bell className="w-4 h-4" /> Set Alarm
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default StopwatchWidget;
