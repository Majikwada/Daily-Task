import { useState, useEffect, useRef } from 'react';
import { Timer, Play, Pause, RotateCcw } from 'lucide-react';

const PomodoroWidget = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const workTime = 25 * 60;
  const breakTime = 5 * 60;

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      if (mode === 'work') {
        setMode('break');
        setTimeLeft(breakTime);
      } else {
        setMode('work');
        setTimeLeft(workTime);
      }
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timeLeft, mode]);

  const toggleTimer = () => setIsRunning(!isRunning);

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(mode === 'work' ? workTime : breakTime);
  };

  const switchMode = (newMode: 'work' | 'break') => {
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(newMode === 'work' ? workTime : breakTime);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'work' 
    ? ((workTime - timeLeft) / workTime) * 100 
    : ((breakTime - timeLeft) / breakTime) * 100;

  return (
    <div className="widget-card">
      <div className="flex items-center gap-2 mb-4">
        <Timer className="w-4 h-4 text-primary" />
        <span className="widget-title mb-0">Pomodoro</span>
      </div>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => switchMode('work')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium transition-all duration-200 ${
            mode === 'work'
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-secondary-foreground hover:bg-muted'
          }`}
        >
          Focus
        </button>
        <button
          onClick={() => switchMode('break')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium transition-all duration-200 ${
            mode === 'break'
              ? 'bg-accent text-accent-foreground'
              : 'bg-secondary text-secondary-foreground hover:bg-muted'
          }`}
        >
          Break
        </button>
      </div>

      <div className="relative flex items-center justify-center mb-4">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="58"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              className="text-secondary"
            />
            <circle
              cx="64"
              cy="64"
              r="58"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 58}`}
              strokeDashoffset={`${2 * Math.PI * 58 * (1 - progress / 100)}`}
              className={`${mode === 'work' ? 'text-primary' : 'text-accent'} transition-all duration-300`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl font-light tabular-nums text-foreground">
              {formatTime(timeLeft)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex gap-2 justify-center">
        <button
          onClick={toggleTimer}
          className={`p-3 rounded-xl transition-all duration-200 ${
            isRunning
              ? 'bg-muted text-foreground hover:bg-secondary'
              : 'bg-primary text-primary-foreground hover:opacity-90'
          }`}
        >
          {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </button>
        <button
          onClick={resetTimer}
          className="p-3 rounded-xl bg-secondary text-secondary-foreground hover:bg-muted transition-all duration-200"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default PomodoroWidget;
