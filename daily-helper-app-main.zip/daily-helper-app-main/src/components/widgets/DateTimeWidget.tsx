import { useState, useEffect } from 'react';
import { Calendar, Clock } from 'lucide-react';

const DateTimeWidget = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <div className="widget-card col-span-2 lg:col-span-1">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-4 h-4 text-primary" />
        <span className="widget-title mb-0">Today</span>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-display font-semibold text-foreground">
          {getGreeting()}
        </h2>
        <p className="text-4xl font-light text-primary tabular-nums">
          {formatTime(currentTime)}
        </p>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">{formatDate(currentTime)}</span>
        </div>
      </div>
    </div>
  );
};

export default DateTimeWidget;
