import { useState } from 'react';
import { Target, Plus } from 'lucide-react';

interface Habit {
  id: number;
  name: string;
  emoji: string;
  streak: number;
  completedToday: boolean;
}

const HabitWidget = () => {
  const [habits, setHabits] = useState<Habit[]>([
    { id: 1, name: 'Exercise', emoji: '🏃', streak: 5, completedToday: false },
    { id: 2, name: 'Read', emoji: '📚', streak: 12, completedToday: true },
    { id: 3, name: 'Meditate', emoji: '🧘', streak: 3, completedToday: false },
    { id: 4, name: 'Hydrate', emoji: '💧', streak: 8, completedToday: true },
  ]);

  const toggleHabit = (id: number) => {
    setHabits(habits.map(habit => {
      if (habit.id === id) {
        return {
          ...habit,
          completedToday: !habit.completedToday,
          streak: !habit.completedToday ? habit.streak + 1 : Math.max(0, habit.streak - 1),
        };
      }
      return habit;
    }));
  };

  const completedCount = habits.filter(h => h.completedToday).length;

  return (
    <div className="widget-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-accent" />
          <span className="widget-title mb-0">Habits</span>
        </div>
        <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-full">
          {completedCount}/{habits.length} today
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {habits.map((habit) => (
          <button
            key={habit.id}
            onClick={() => toggleHabit(habit.id)}
            className={`p-3 rounded-xl text-left transition-all duration-200 ${
              habit.completedToday
                ? 'bg-primary/10 border-2 border-primary'
                : 'bg-secondary hover:bg-muted border-2 border-transparent'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">{habit.emoji}</span>
              <span className="text-sm font-medium text-foreground">{habit.name}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs text-muted-foreground">🔥 {habit.streak} days</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default HabitWidget;
