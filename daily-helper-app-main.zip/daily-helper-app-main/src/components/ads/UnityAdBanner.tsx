import { useEffect } from 'react';

declare global {
  interface Window {
    unityAds?: {
      initialize: (gameId: string, testMode: boolean) => void;
      showBanner: (placement: string, containerId: string) => void;
      showInterstitial: (placement: string) => void;
      showRewarded: (placement: string, callback: (result: string) => void) => void;
    };
  }
}

interface UnityAdBannerProps {
  gameId: string;
  placementId: string;
  containerId?: string;
  testMode?: boolean;
}

const UnityAdBanner = ({ 
  gameId, 
  placementId, 
  containerId = 'unity-ad-container',
  testMode = false 
}: UnityAdBannerProps) => {
  useEffect(() => {
    // Load Unity Ads SDK
    const existingScript = document.querySelector('script[src*="unity-ads"]');
    if (!existingScript) {
      const script = document.createElement('script');
      script.src = 'https://unity-ads.unity3d.com/unity-ads.js';
      script.async = true;
      script.onload = () => {
        if (window.unityAds) {
          window.unityAds.initialize(gameId, testMode);
          setTimeout(() => {
            window.unityAds?.showBanner(placementId, containerId);
          }, 1000);
        }
      };
      document.head.appendChild(script);
    } else if (window.unityAds) {
      window.unityAds.showBanner(placementId, containerId);
    }
  }, [gameId, placementId, containerId, testMode]);

  return (
    <div 
      id={containerId}
      className="w-full min-h-[60px] bg-gradient-to-r from-secondary to-muted rounded-xl flex items-center justify-center overflow-hidden border border-border"
    >
      <div className="flex items-center gap-2 text-muted-foreground">
        <div className="w-2 h-2 bg-primary/50 rounded-full animate-pulse" />
        <span className="text-xs">Loading Ad...</span>
      </div>
    </div>
  );
};

// Show interstitial ad
export const showInterstitialAd = (gameId: string, placementId: string) => {
  if (window.unityAds) {
    window.unityAds.showInterstitial(placementId);
  }
};

// Show rewarded ad with callback
export const showRewardedAd = (
  gameId: string, 
  placementId: string, 
  onComplete: (success: boolean) => void
) => {
  if (window.unityAds) {
    window.unityAds.showRewarded(placementId, (result) => {
      onComplete(result === 'COMPLETED');
    });
  } else {
    onComplete(false);
  }
};

export default UnityAdBanner;
